<?php

class WP_Tests_Exception extends PHPUnit_Framework_Exception {
	
}